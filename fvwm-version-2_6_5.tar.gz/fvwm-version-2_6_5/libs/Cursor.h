int fvwmCursorNameToIndex (char *cursor_name);
